# 라이다 G4 + ANT+ 통합 시스템

라이다 G4 터치스크린과 ANT+ 심박계를 하나의 앱에서 제어합니다.

---

## 파일 구성

```
통합/
├── main.py             # 진입점
├── lidar_ui.py         # 통합 UI (라이다 + ANT+)
├── lidar_core.py       # 라이다 핵심 로직
├── ant_controller.py   # ANT+ 백그라운드 컨트롤러
├── config_manager.py   # 설정 관리
├── lidar_config.json   # 설정 파일
├── build.py            # 빌드 스크립트
├── build.spec          # PyInstaller spec
└── requirements.txt    # 의존성 패키지
```

---

## 사전 준비

### 1. Python 패키지 설치

```bash
pip install -r requirements.txt
```

### 2. libusb-1.0.dll 확인 (ANT+ 필수)

ANT+ 동글 사용을 위해 `libusb-1.0.dll`이 필요합니다.  
`build.py` 상단의 `LIBUSB_DLL` 경로가 실제 DLL 위치와 일치하는지 확인하세요.

```python
# build.py 상단
LIBUSB_DLL = "C:/Program Files (x86)/Steam/libusb-1.0.dll"
```

DLL이 없는 경우 [libusb 공식 사이트](https://libusb.info)에서 다운로드하거나,  
Steam이 설치되어 있다면 해당 경로에 이미 존재합니다.

### 3. ANT+ 동글 드라이버 설정

ANT+ USB 동글을 처음 사용하는 경우 **Zadig**으로 드라이버를 교체해야 합니다.

1. [Zadig 다운로드](https://zadig.akeo.ie/)
2. ANT+ 동글 선택
3. 드라이버를 **WinUSB** 또는 **libusb-win32** 로 교체

---

## 실행 (소스 직접 실행)

```bash
cd 통합
python main.py
```

---

## 빌드 방법

### GUI 버전 빌드 (기본)

콘솔창 없이 GUI만 실행되는 버전입니다.

```bash
python build.py
```

출력: `dist/LidarANT.exe`

---

### 콘솔 버전 빌드 (디버그용)

오류 로그를 콘솔창에서 확인할 수 있는 버전입니다.

```bash
python build.py --console
```

출력: `dist/LidarANT_Console.exe`

---

### GUI + 콘솔 모두 빌드

```bash
python build.py --all
```

출력: `dist/LidarANT.exe`, `dist/LidarANT_Console.exe`

---

### 빌드 폴더 정리

```bash
python build.py --clean
```

`build/`, `dist/`, `__pycache__/` 폴더를 삭제합니다.

---

## 배포 시 주의사항

빌드 후 `dist/` 폴더에 아래 파일이 함께 있어야 합니다.

| 파일 | 설명 |
|------|------|
| `LidarANT.exe` | 실행 파일 |
| `lidar_config.json` | 설정 파일 (빌드 스크립트가 자동 복사) |

> `lidar_config.json`이 없으면 기본값으로 동작합니다.

---

## 기능

| 탭 | 기능 |
|----|------|
| 라이다 설정 | COM 포트 연결, 스캔 범위, 터치 영역, 마우스 제어 |
| ANT+ 설정 | 심박계 연결, BPM 표시, UDP 전송 설정 |

- ANT+ 오류 발생 시 **3초 후 자동 재시도** (앱 종료 없음)
- UDP로 BPM 데이터를 Unity 등 외부 앱에 전송 (기본: `127.0.0.1:5005`)
